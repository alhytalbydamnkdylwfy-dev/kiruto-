# KIRUTO
موقع اختبار اجتماعي عربي من 20 سؤالًا.

## التشغيل
افتح `index.html` مباشرة في Chrome.

## النشر المجاني
ارفع الملفات الثلاثة إلى GitHub Pages:
`index.html` + `style.css` + `script.js`

ثم فعّل Settings → Pages → Deploy from branch.
